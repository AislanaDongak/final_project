const KEY='terra-brandbook-v1';
export const palettes={forest:{name:'Лесная',bg:'#F5F0E6',ink:'#193C2C',accent:'#B8D16B',secondary:'#E0E9CE'},bloom:{name:'Цветущая',bg:'#FFF0E8',ink:'#633947',accent:'#F1A086',secondary:'#FAD2C5'},dusk:{name:'Сумеречная',bg:'#EDEBF6',ink:'#25365B',accent:'#AC9BE0',secondary:'#D9CFF2'}};
export const defaults={name:'ТЕРРА',slogan:'Природа ближе, чем кажется.',paletteId:'forest',posterPaletteId:'forest',season:'summer',font:'serif',fontSize:56,weight:700,layout:'editorial',plant:'monstera',route:'jungle'};
let state={...defaults};let storage=true;
try{const raw=localStorage.getItem(KEY);if(raw){const parsed=JSON.parse(raw);if(parsed&&typeof parsed==='object')state={...defaults,...parsed}}}catch(e){storage=false}
export function getState(){return {...state}}
export function patch(changes){state={...state,...changes};try{localStorage.setItem(KEY,JSON.stringify(state))}catch(e){storage=false}applyTheme();window.dispatchEvent(new CustomEvent('brandchange',{detail:getState()}));return getState()}
export function reset(){state={...defaults};try{localStorage.removeItem(KEY)}catch(e){storage=false}applyTheme();window.dispatchEvent(new CustomEvent('brandchange',{detail:getState()}))}
export function subscribe(cb){window.addEventListener('brandchange',()=>cb(getState()));cb(getState())}
export function applyTheme(){const p=document.body.classList.contains('color-page') ? (palettes[state.paletteId]||palettes.forest) : palettes.forest;for(const [k,v] of Object.entries(p))document.documentElement.style.setProperty('--'+k,v);document.documentElement.dataset.palette=state.paletteId;const warn=document.querySelector('[data-storage-warning]');if(warn)warn.hidden=storage}
applyTheme();
